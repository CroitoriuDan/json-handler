<!-- resources/views/devices/edit.blade.php -->

<!-- <h1>Edit Device</h1>
<form action="<?php echo e(route('devices.update', $device)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="device_id">Device ID:</label>
    <input type="text" name="device_id" value="<?php echo e($device->device_id); ?>" required>
    <label for="location_name">Location Name:</label>
    <input type="text" name="location_name" value="<?php echo e($device->location_name); ?>" required>
    <button type="submit">Update Device</button>
</form>
<a href="<?php echo e(route('devices.show', $device)); ?>">Back to Device Details</a> -->


<!-- Form for updating the device information -->
<!-- <form method="post" action="<?php echo e(route('devices.update', ['device' => $device->id])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    
    <label for="location_name">Location Name:</label>
    <input type="text" name="location_name" value="<?php echo e(old('location_name', $device->location_name)); ?>">

   
    <?php $__currentLoopData = $device->detergentPumps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pump): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label for="detergent_pumps[<?php echo e($index); ?>][name]">Pump Name:</label>
        <input type="text" name="detergent_pumps[<?php echo e($index); ?>][name]" value="<?php echo e(old('detergent_pumps.'.$index.'.name', $pump->name)); ?>">

        <label for="detergent_pumps[<?php echo e($index); ?>][dosage]">Dosage:</label>
        <input type="text" name="detergent_pumps[<?php echo e($index); ?>][dosage]" value="<?php echo e(old('detergent_pumps.'.$index.'.dosage', $pump->dosage)); ?>">

        <label for="detergent_pumps[<?php echo e($index); ?>][active]">Active:</label>
        <input type="checkbox" name="detergent_pumps[<?php echo e($index); ?>][active]" <?php echo e(old('detergent_pumps.'.$index.'.active', $pump->active) ? 'checked' : ''); ?>>

        <label for="detergent_pumps[<?php echo e($index); ?>][trigger]">Trigger:</label>
        <input type="text" name="detergent_pumps[<?php echo e($index); ?>][trigger]" value="<?php echo e(old('detergent_pumps.'.$index.'.trigger', $pump->trigger)); ?>">

        <label for="detergent_pumps[<?php echo e($index); ?>][xp]">XP:</label>
        <input type="text" name="detergent_pumps[<?php echo e($index); ?>][xp]" value="<?php echo e(old('detergent_pumps.'.$index.'.xp', $pump->xp)); ?>">

        <label for="detergent_pumps[<?php echo e($index); ?>][xt]">XT:</label>
        <input type="text" name="detergent_pumps[<?php echo e($index); ?>][xt]" value="<?php echo e(old('detergent_pumps.'.$index.'.xt', $pump->xt)); ?>">

        <label for="detergent_pumps[<?php echo e($index); ?>][total]">Total:</label>
        <input type="text" name="detergent_pumps[<?php echo e($index); ?>][total]" value="<?php echo e(old('detergent_pumps.'.$index.'.total', $pump->total)); ?>">

        <label for="detergent_pumps[<?php echo e($index); ?>][remaining]">Remaining:</label>
        <input type="text" name="detergent_pumps[<?php echo e($index); ?>][remaining]" value="<?php echo e(old('detergent_pumps.'.$index.'.remaining', $pump->remaining)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   
    <button type="submit">Update Device</button>
</form> -->


<!-- Form for updating the device information -->
<!-- <form method="post" action="<?php echo e(route('devices.update', ['device' => $device->id])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <div class="container mt-4">
        <h3>Edit Device</h3>

        
        <div class="form-group">
            <label for="location_name">Location Name:</label>
            <input type="text" class="form-control" name="location_name" value="<?php echo e(old('location_name', $device->location_name)); ?>">
        </div>

        
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Dosage</th>
                    <th>Active</th>
                    <th>Trigger</th>
                    <th>XP</th>
                    <th>XT</th>
                    <th>Total</th>
                    <th>Remaining</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $device->detergentPumps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pump): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][name]" value="<?php echo e(old('detergent_pumps.'.$index.'.name', $pump->name)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][dosage]" value="<?php echo e(old('detergent_pumps.'.$index.'.dosage', $pump->dosage)); ?>">
                        </td>
                        <td>
                            <input type="checkbox" class="form-check-input" name="detergent_pumps[<?php echo e($index); ?>][active]" <?php echo e(old('detergent_pumps.'.$index.'.active', $pump->active) ? 'checked' : ''); ?>>
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][trigger]" value="<?php echo e(old('detergent_pumps.'.$index.'.trigger', $pump->trigger)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][xp]" value="<?php echo e(old('detergent_pumps.'.$index.'.xp', $pump->xp)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][xt]" value="<?php echo e(old('detergent_pumps.'.$index.'.xt', $pump->xt)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][total]" value="<?php echo e(old('detergent_pumps.'.$index.'.total', $pump->total)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][remaining]" value="<?php echo e(old('detergent_pumps.'.$index.'.remaining', $pump->remaining)); ?>">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

       

        
        <button type="submit" class="btn btn-primary">Update Device</button>
    </div>
</form> -->



<!-- Form for updating the device information -->
<!-- <form method="post" action="<?php echo e(route('devices.update', ['device' => $device->id])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <div class="container mt-4">
        <h3>Edit Device</h3>

        
        <div class="form-group">
            <label for="location_name">Location Name:</label>
            <input type="text" class="form-control" name="location_name" value="<?php echo e(old('location_name', $device->location_name)); ?>">
        </div>

        
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Dosage</th>
                    <th>Active</th>
                    <th>Trigger</th>
                    <th>XP</th>
                    <th>XT</th>
                    <th>Total</th>
                    <th>Remaining</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $device->detergentPumps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pump): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <input type="hidden" name="detergent_pumps[<?php echo e($index); ?>][id]" value="<?php echo e($pump->id); ?>">
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][name]" value="<?php echo e(old('detergent_pumps.'.$index.'.name', $pump->name)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][dosage]" value="<?php echo e(old('detergent_pumps.'.$index.'.dosage', $pump->dosage)); ?>">
                        </td>
                        <td>
                            <input type="checkbox" class="form-check-input" name="detergent_pumps[<?php echo e($index); ?>][active]" <?php echo e(old('detergent_pumps.'.$index.'.active', $pump->active) ? 'checked' : ''); ?>>
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][trigger]" value="<?php echo e(old('detergent_pumps.'.$index.'.trigger', $pump->trigger)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][xp]" value="<?php echo e(old('detergent_pumps.'.$index.'.xp', $pump->xp)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][xt]" value="<?php echo e(old('detergent_pumps.'.$index.'.xt', $pump->xt)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][total]" value="<?php echo e(old('detergent_pumps.'.$index.'.total', $pump->total)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][remaining]" value="<?php echo e(old('detergent_pumps.'.$index.'.remaining', $pump->remaining)); ?>">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <button type="submit" class="btn btn-primary">Update Device</button>
    </div>
</form> -->


<!-- <form method="post" action="<?php echo e(route('devices.update', ['device' => $device->id])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>

    <div class="container mt-4">
        <h3>Edit Device</h3>

        <div class="form-group">
            <label for="location_name">Location Name:</label>
            <input type="text" class="form-control" name="location_name" value="<?php echo e(old('location_name', $device->location_name)); ?>">
        </div>

        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Dosage</th>
                    <th>Active</th>
                    <th>Trigger</th>
                    <th>XP</th>
                    <th>XT</th>
                    <th>Total</th>
                    <th>Remaining</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $device->detergentPumps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pump): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <input type="hidden" name="detergent_pumps[<?php echo e($index); ?>][id]" value="<?php echo e($pump->id); ?>">
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][name]" value="<?php echo e(old('detergent_pumps.'.$index.'.name', $pump->name)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][dosage]" value="<?php echo e(old('detergent_pumps.'.$index.'.dosage', $pump->dosage)); ?>">
                        </td>
                        <td>
                            <input type="checkbox" class="form-check-input" name="detergent_pumps[<?php echo e($index); ?>][active]" <?php echo e(old('detergent_pumps.'.$index.'.active', $pump->active) ? 'checked' : ''); ?>>
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][trigger]" value="<?php echo e(old('detergent_pumps.'.$index.'.trigger', $pump->trigger)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][xp]" value="<?php echo e(old('detergent_pumps.'.$index.'.xp', $pump->xp)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][xt]" value="<?php echo e(old('detergent_pumps.'.$index.'.xt', $pump->xt)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][total]" value="<?php echo e(old('detergent_pumps.'.$index.'.total', $pump->total)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][remaining]" value="<?php echo e(old('detergent_pumps.'.$index.'.remaining', $pump->remaining)); ?>">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

       
        <button type="submit" class="btn btn-primary">Update Device</button>
    </div>
</form> -->


<!-- resources/views/devices/edit.blade.php -->

<?php if(!empty($errors->messages())): ?>
    <?php echo e(dd($errors->messages())); ?>

<?php endif; ?>

<form method="post" action="<?php echo e(route('devices.update', ['device' => $device->id])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>

    <div class="container mt-4">
        <h3>Edit Device</h3>

        <!-- Device fields -->
        <div class="form-group">
            <label for="location_name">Location Name:</label>
            <input type="text" class="form-control" name="location_name" value="<?php echo e(old('location_name', $device->location_name)); ?>">
        </div>

        <!-- Detergent pumps fields -->
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Dosage</th>
                    <th>Active</th>
                    <th>Trigger</th>
                    <th>XP</th>
                    <th>XT</th>
                    <th>Total</th>
                    <th>Remaining</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $device->detergentPumps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pump): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][name]" value="<?php echo e(old('detergent_pumps.'.$index.'.name', $pump->name)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][dosage]" value="<?php echo e(old('detergent_pumps.'.$index.'.dosage', $pump->dosage)); ?>">
                        </td>
                        <!-- <td>
                            <input type="checkbox" class="form-check-input" name="detergent_pumps[<?php echo e($index); ?>][active]" <?php echo e(old('detergent_pumps.'.$index.'.active', $pump->active) ? 'checked' : ''); ?>>
                        </td> -->

                        <td>
                        <input type="hidden" name="detergent_pumps[<?php echo e($index); ?>][active]" value="false">
                        <input type="checkbox" class="form-check-input" name="detergent_pumps[<?php echo e($index); ?>][active]" <?php echo e(old('detergent_pumps.'.$index.'.active', $pump->active) ? 'checked' : ''); ?>>
                        </td>



                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][trigger]" value="<?php echo e(old('detergent_pumps.'.$index.'.trigger', $pump->trigger)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][xp]" value="<?php echo e(old('detergent_pumps.'.$index.'.xp', $pump->xp)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][xt]" value="<?php echo e(old('detergent_pumps.'.$index.'.xt', $pump->xt)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][total]" value="<?php echo e(old('detergent_pumps.'.$index.'.total', $pump->total)); ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="detergent_pumps[<?php echo e($index); ?>][remaining]" value="<?php echo e(old('detergent_pumps.'.$index.'.remaining', $pump->remaining)); ?>">
                        </td>
                        <input type="hidden" name="detergent_pumps[<?php echo e($index); ?>][id]" value="<?php echo e($pump->id); ?>">
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Add more detergent pumps if needed -->

        <!-- Submit button -->
        <button type="submit" class="btn btn-primary">Update Device</button>
    </div>
</form>
<?php /**PATH E:\xampp\htdocs\beje\jsonhandler\resources\views/devices/edit.blade.php ENDPATH**/ ?>