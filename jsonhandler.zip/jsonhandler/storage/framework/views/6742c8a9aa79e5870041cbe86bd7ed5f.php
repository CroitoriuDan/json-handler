<!-- resources/views/devices/show.blade.php -->

<h1>Device Details</h1>
<p>ID: <?php echo e($device->id); ?></p>
<p>Device ID: <?php echo e($device->device_id); ?></p>
<p>Location Name: <?php echo e($device->location_name); ?></p>
<!-- Add more details as needed -->
<a href="<?php echo e(route('devices.edit', $device)); ?>">Edit Device</a>
<form action="<?php echo e(route('devices.destroy', $device)); ?>" method="post" style="display: inline;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit">Delete</button>
</form>
<a href="<?php echo e(route('devices.index')); ?>">Back to Devices</a>
<?php /**PATH E:\xampp\htdocs\beje\jsonhandler\resources\views/devices/show.blade.php ENDPATH**/ ?>