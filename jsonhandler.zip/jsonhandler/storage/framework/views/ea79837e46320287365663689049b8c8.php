<h1>Devices</h1>
<ul>
    <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('devices.show', $device)); ?>"><?php echo e($device->location_name); ?></a>
            <form action="<?php echo e(route('devices.destroy', $device)); ?>" method="post" style="display: inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit">Delete</button>
            </form>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<a href="<?php echo e(route('devices.create')); ?>">Create New Device</a><?php /**PATH E:\xampp\htdocs\beje\jsonhandler\resources\views/devices/index.blade.php ENDPATH**/ ?>