<!-- resources/views/devices/create.blade.php -->

<h1>Create New Device</h1>
<form action="<?php echo e(route('devices.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="device_id">Device ID:</label>
    <input type="text" name="device_id" required>
    <label for="location_name">Location Name:</label>
    <input type="text" name="location_name" required>
    <!-- Add more fields as needed -->
    <button type="submit">Create Device</button>
</form>
<a href="<?php echo e(route('devices.index')); ?>">Back to Devices</a>
<?php /**PATH E:\xampp\htdocs\beje\jsonhandler\resources\views/devices/create.blade.php ENDPATH**/ ?>